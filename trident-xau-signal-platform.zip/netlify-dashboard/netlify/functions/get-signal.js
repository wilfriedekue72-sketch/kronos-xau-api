// netlify/functions/get-signal.js
//
// Orchestrates the whole signal pipeline:
//   1. Pull recent XAU/USD candles from Twelve Data
//   2. Send them to the Kronos HF Space for a forecast
//   3. Turn the forecast into a directional bias + entry/SL/TP
//   4. Size the position against YOUR account balance + risk %
//
// This function holds no API keys client-side — they live in Netlify
// environment variables (Site settings -> Environment variables):
//   TWELVE_DATA_API_KEY   (required)  - free key from twelvedata.com
//   KRONOS_API_URL         (required)  - e.g. https://your-name-space.hf.space
//   KRONOS_API_KEY         (optional)  - only if you set API_KEY on the HF Space

const TWELVE_DATA_BASE = "https://api.twelvedata.com";

exports.handler = async (event) => {
  try {
    const params = event.httpMethod === "POST"
      ? JSON.parse(event.body || "{}")
      : event.queryStringParameters || {};

    const accountBalance = Number(params.accountBalance ?? 1000);
    const riskPercent = Number(params.riskPercent ?? 1);
    const contractSize = Number(params.contractSize ?? 100); // oz per standard lot
    const lotStep = Number(params.lotStep ?? 0.01);
    const interval = params.interval || "15min"; // twelve data interval
    const intervalMinutes = intervalToMinutes(interval);
    const predLen = Number(params.predLen ?? 12);
    const stopAtrMultiple = Number(params.stopAtrMultiple ?? 1.5);

    const TWELVE_DATA_API_KEY = process.env.TWELVE_DATA_API_KEY;
    const KRONOS_API_URL = process.env.KRONOS_API_URL;
    const KRONOS_API_KEY = process.env.KRONOS_API_KEY || "";

    if (!TWELVE_DATA_API_KEY) {
      return errorResponse(500, "Missing TWELVE_DATA_API_KEY environment variable on Netlify.");
    }
    if (!KRONOS_API_URL) {
      return errorResponse(500, "Missing KRONOS_API_URL environment variable on Netlify.");
    }

    // 1. Historical candles ---------------------------------------------------
    const candles = await fetchCandles(TWELVE_DATA_API_KEY, interval);
    if (!candles || candles.length < 30) {
      return errorResponse(502, "Not enough candle data returned from Twelve Data.");
    }
    const lastCandle = candles[candles.length - 1];
    const lastPrice = lastCandle.close;

    // 2. ATR(14) for stop-loss sizing -----------------------------------------
    const atr = computeATR(candles, 14);

    // 3. Kronos forecast --------------------------------------------------------
    const forecastResp = await fetch(`${KRONOS_API_URL.replace(/\/$/, "")}/forecast`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(KRONOS_API_KEY ? { "x-api-key": KRONOS_API_KEY } : {}),
      },
      body: JSON.stringify({
        candles: candles.slice(-512), // Kronos max context
        pred_len: predLen,
        interval_minutes: intervalMinutes,
        T: 1.0,
        top_p: 0.9,
        sample_count: 3,
      }),
    });

    if (!forecastResp.ok) {
      const text = await forecastResp.text();
      // Common case: Render free tier spun down and is cold-starting
      return errorResponse(
        502,
        `Kronos API error (${forecastResp.status}). If this is the first request in a while, the ` +
        `free Render service may be waking up from being spun down — wait ~30-60s and try again. Details: ${text.slice(0, 300)}`
      );
    }
    const forecastData = await forecastResp.json();
    const forecast = forecastData.forecast;
    const forecastPaths = forecastData.forecast_paths;

    // 4. Direction + confidence from the forecast --------------------------
    const forecastMeanClose = average(forecast.map((c) => c.close));
    const priceDeltaPct = ((forecastMeanClose - lastPrice) / lastPrice) * 100;

    // Confidence: how tightly the sampled forecast paths agree with each other.
    // Narrow spread across sampled paths = model is more confident about direction.
    const finalCloses = forecastPaths.map((path) => path[path.length - 1].close);
    const pathSpreadPct = (Math.max(...finalCloses) - Math.min(...finalCloses)) / lastPrice * 100;
    const confidence = clamp(100 - pathSpreadPct * 40, 5, 95); // heuristic, not statistical

    const NEUTRAL_BAND_PCT = 0.05; // moves smaller than this are treated as noise
    let direction = "neutral";
    if (priceDeltaPct > NEUTRAL_BAND_PCT) direction = "long";
    else if (priceDeltaPct < -NEUTRAL_BAND_PCT) direction = "short";

    // 5. Entry / stop-loss / take-profit ------------------------------------
    const entry = lastPrice;
    let stopLoss, takeProfit;
    if (direction === "long") {
      stopLoss = entry - atr * stopAtrMultiple;
      const forecastHigh = Math.max(...forecast.map((c) => c.high));
      takeProfit = Math.max(forecastHigh, entry + (entry - stopLoss) * 2); // at least 1:2 RR
    } else if (direction === "short") {
      stopLoss = entry + atr * stopAtrMultiple;
      const forecastLow = Math.min(...forecast.map((c) => c.low));
      takeProfit = Math.min(forecastLow, entry - (stopLoss - entry) * 2);
    } else {
      stopLoss = entry - atr * stopAtrMultiple;
      takeProfit = entry + atr * stopAtrMultiple;
    }

    const stopDistance = Math.abs(entry - stopLoss);
    const riskRewardRatio = stopDistance > 0 ? Math.abs(takeProfit - entry) / stopDistance : 0;

    // 6. Position sizing against YOUR account -------------------------------
    const riskAmount = accountBalance * (riskPercent / 100);
    const dollarRiskPerLot = stopDistance * contractSize;
    let lotSize = dollarRiskPerLot > 0 ? riskAmount / dollarRiskPerLot : 0;
    lotSize = Math.floor(lotSize / lotStep) * lotStep; // round down to broker's lot step
    lotSize = Math.max(lotSize, 0);

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        asOf: new Date().toISOString(),
        symbol: "XAU/USD",
        interval,
        lastPrice,
        atr14: round(atr, 3),
        historical: candles.slice(-150), // enough for the chart without a huge payload
        forecast,
        forecastPaths,
        signal: {
          direction,
          confidencePct: round(confidence, 1),
          priceDeltaPct: round(priceDeltaPct, 3),
          entry: round(entry, 2),
          stopLoss: round(stopLoss, 2),
          takeProfit: round(takeProfit, 2),
          riskRewardRatio: round(riskRewardRatio, 2),
        },
        risk: {
          accountBalance,
          riskPercent,
          riskAmount: round(riskAmount, 2),
          contractSize,
          lotSize: round(lotSize, 2),
        },
        model: forecastData.model,
        disclaimer:
          "Generated from a statistical forecast model, not financial advice. Gold is volatile — " +
          "confirm against your own analysis before risking real capital.",
      }),
    };
  } catch (err) {
    return errorResponse(500, err.message || String(err));
  }
};

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
async function fetchCandles(apiKey, interval) {
  const url = `${TWELVE_DATA_BASE}/time_series?symbol=XAU/USD&interval=${interval}&outputsize=500&order=ASC&apikey=${apiKey}`;
  const resp = await fetch(url);
  const data = await resp.json();
  if (data.status === "error" || !data.values) {
    throw new Error(`Twelve Data error: ${data.message || JSON.stringify(data)}`);
  }
  return data.values.map((v) => ({
    timestamp: new Date(v.datetime.replace(" ", "T") + "Z").toISOString(),
    open: Number(v.open),
    high: Number(v.high),
    low: Number(v.low),
    close: Number(v.close),
    volume: Number(v.volume || 0),
  }));
}

function computeATR(candles, period) {
  const trs = [];
  for (let i = 1; i < candles.length; i++) {
    const cur = candles[i];
    const prev = candles[i - 1];
    const tr = Math.max(
      cur.high - cur.low,
      Math.abs(cur.high - prev.close),
      Math.abs(cur.low - prev.close)
    );
    trs.push(tr);
  }
  const last = trs.slice(-period);
  return average(last);
}

function intervalToMinutes(interval) {
  const map = { "1min": 1, "5min": 5, "15min": 15, "30min": 30, "45min": 45, "1h": 60, "2h": 120, "4h": 240, "1day": 1440 };
  return map[interval] || 15;
}

function average(arr) {
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}

function clamp(v, min, max) {
  return Math.max(min, Math.min(max, v));
}

function round(v, dp) {
  const f = Math.pow(10, dp);
  return Math.round(v * f) / f;
}

function errorResponse(statusCode, message) {
  return {
    statusCode,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ error: message }),
  };
}
