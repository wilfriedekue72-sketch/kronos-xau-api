# Trident XAU Signal — standalone gold signal dashboard

A personal-use dashboard that forecasts XAU/USD with the Kronos foundation model and turns
that forecast into a signal (direction + entry/stop/target) sized against **your** account
balance and risk %. No payments, no multi-user auth — it's just for you.

## How it fits together

```
┌─────────────────────┐        ┌──────────────────────┐        ┌────────────────────────┐
│   Twelve Data API    │ ────▶  │  Netlify function     │ ────▶  │   Your browser          │
│  (XAU/USD candles)   │        │  get-signal.js        │        │   dashboard (index.html)│
└─────────────────────┘        │  - fetches candles    │        └────────────────────────┘
                                │  - calls Kronos API   │
                                │  - computes ATR/SL/TP │
┌─────────────────────┐        │  - sizes position     │
│  Render (free)        │ ◀──── │    against your risk  │
│  Kronos model (app.py)│        └──────────────────────┘
└─────────────────────┘
```

Two things to deploy, in this order:

### 1. The Kronos model API (Render — free, no card)

Everything's in `render-kronos-api/`. Full steps are in that folder's `README.md`. Short version:
push this folder to a GitHub repo, connect it to a free Render web service, it builds from the
included `Dockerfile`. Note the resulting URL (`https://kronos-xau-api.onrender.com`) — you'll
need it next.

*(This originally targeted a free Hugging Face Space, then Google Cloud Run — HF moved Docker
Spaces behind a paid plan, and Cloud Run needs a card on file even for free-tier use. Render's
free tier needs neither, at the cost of a smaller/lower-quality model and slower cold starts.)*

### 2. The dashboard (Netlify — free)

Everything's in `netlify-dashboard/`.

1. Get a free API key from https://twelvedata.com (covers XAU/USD candles, free tier is
   plenty for manual refreshes).
2. Push `netlify-dashboard/` to a new GitHub repo (or drag-and-drop deploy the folder directly
   on Netlify — either works since there's no build step).
3. On Netlify: **Add new site -> Import from Git** (or drag-and-drop), pick this folder.
4. In **Site settings -> Environment variables**, add:
   - `TWELVE_DATA_API_KEY` — from step 1
   - `KRONOS_API_URL` — your Render service URL from part 1
   - `KRONOS_API_KEY` — the random string you set as `API_KEY` on Render
5. Deploy. Open the site — it auto-fetches a signal on load, and you can adjust your balance/risk
   % and hit **Get signal** any time.

## What it does NOT do

- It does not place trades. It's a read-only dashboard.
- It does not store history or accounts — refresh-on-demand, single user.
- It is not connected to MT5/MetaApi. If you later want this feeding into XAUSEA AUTO for
  execution, the `get-signal` function already returns a clean JSON signal object
  (`direction`, `entry`, `stopLoss`, `takeProfit`, `lotSize`) that's easy to pipe into that
  pipeline — just say the word and we can wire it up.

## Honest limitations worth knowing

- Kronos is a general-purpose candlestick forecaster, not a gold specialist — it wasn't
  fine-tuned on XAU/USD specifically. Treat its output as one signal among several, not gospel.
- Render's free tier spins down after 15 minutes of inactivity and takes ~30-60s to wake up on the
  first request after a while — expect an occasional slow first refresh.
- It's running `kronos-mini` (the smallest, fastest Kronos variant) to fit Render's free 512MB
  RAM limit — forecast quality is lower than `kronos-small`/`kronos-base`. See
  `render-kronos-api/README.md` for the upgrade path if you want better quality later.
- The "confidence" score in the signal card is a simple heuristic (spread across sampled
  forecast paths), not a calibrated statistical probability.
- Position sizing assumes a standard XAUUSD contract of 100oz/lot — check your specific broker,
  since some quote gold in different contract sizes or pip conventions, and adjust the
  "Contract size" dropdown accordingly.
